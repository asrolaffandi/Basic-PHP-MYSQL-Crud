
1.Import employees.sql table to your mysql server database
1.Change database username, password and database name inside config.php